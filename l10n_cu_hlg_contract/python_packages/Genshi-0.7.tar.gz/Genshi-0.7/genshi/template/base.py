# -*- coding: utf-8 -*-
#
# Copyright (C) 2006-2010 Edgewall Software
# All rights reserved.
#
# This software is licensed as described in the file COPYING, which
# you should have received as part of this distribution. The terms
# are also available at http://genshi.edgewall.org/wiki/License.
#
# This software consists of voluntary contributions made by many
# individuals. For the exact contribution history, see the revision
# history and logs, available at http://genshi.edgewall.org/log/.

"""Basic templating functionality."""

from collections import deque
import os
import sys

from genshi.compat import StringIO, BytesIO
from genshi.core import Attrs, Stream, StreamEventKind, START, TEXT, _ensure
from genshi.input import ParseError

__all__ = ['Context', 'DirectiveFactory', 'Template', 'TemplateError',
           'TemplateRuntimeError', 'TemplateSyntaxError', 'BadDirectiveError']
__docformat__ = 'restructuredtext en'


class TemplateError(Exception):
    """Base exception class for errors related to template processing."""

    def __init__(self, message, filename=None, lineno=-1, offset=-1):
        """Create the exception.
        
        :param message: the error message
        :param filename: the filename of the template
        :param lineno: the number of line in the template at which the error
                       occurred
        :param offset: the column number at which the error occurred
        """
        if filename is None:
            filename = '<string>'
        self.msg = message #: the error message string
        if filename != '<string>' or lineno >= 0:
            message = '%s (%s, line %d)' % (self.msg, filename, lineno)
        Exception.__init__(self, message)
        self.filename = filename #: the name of the template file
        self.lineno = lineno #: the number of the line containing the error
        self.offset = offset #: the offset on the line


class TemplateSyntaxError(TemplateError):
    """Exception raised when an expression in a template causes a Python syntax
    error, or the template is not well-formed.
    """

    def __init__(self, message, filename=None, lineno=-1, offset=-1):
        """Create the exception
        
        :param message: the error message
        :param filename: the filename of the template
        :param lineno: the number of line in the template at which the error
                       occurred
        :param offset: the column number at which the error occurred
        """
        if isinstance(message, SyntaxError) and message.lineno is not None:
            message = str(message).replace(' (line %d)' % message.lineno, '')
        TemplateError.__init__(self, message, filename, lineno)


class BadDirectiveError(TemplateSyntaxError):
    """Exception raised when an unknown directive is encountered when parsing
    a template.
    
    An unknown directive is any attribute using the namespace for directives,
    with a local name that doesn't match any registered directive.
    """

    def __init__(self, name, filename=None, lineno=-1):
        """Create the exception
        
        :param name: the name of the directive
        :param filename: the filename of the template
        :param lineno: the number of line in the template at which the error
                       occurred
        """
        TemplateSyntaxError.__init__(self, 'bad directive "%s"' % name,
                                     filename, lineno)


class TemplateRuntimeError(TemplateError):
    """Exception raised when an the evaluation of a Python expression in a
    template causes an error.
    """


class Context(object):
    """Container for template input data.
    
    A context provides a stack of scopes (represented by dictionaries).
    
    Template directives such as loops can push a new scope on the stack with
    data that should only be available inside the loop. When the loop
    terminates, that scope can get popped off the stack again.
    
    >>> ctxt = Context(one='foo', other=1)
    >>> ctxt.get('one')
    'foo'
    >>> ctxt.get('other')
    1
    >>> ctxt.push(dict(one='frost'))
    >>> ctxt.get('one')
    'frost'
    >>> ctxt.get('other')
    1
    >>> ctxt.pop()
    {'one': 'frost'}
    >>> ctxt.get('one')
    'foo'
    """

    def __init__(self, **data):
        """Initialize the template context with the given keyword arguments as
        data.
        """
        self.frames = deque([data])
        self.pop = self.frames.popleft
        self.push = self.frames.appendleft
        self._match_templates = []
        self._choice_stack = []

        # Helper functions for use in expressions
        def defined(name):
            """Return whether a variable with the specified name exists in the
            expression scope."""
            return name in self
        def value_of(name, default=None):
            """If a variable of the specified name is defined, return its value.
            Otherwise, return the provided default value, or ``None``."""
            return self.get(name, default)
        data.setdefault('defined', defined)
        data.setdefault('value_of', value_of)

    def __repr__(self):
        return repr(list(self.frames))

    def __contains__(self, key):
        """Return whether a variable exists in any of the scopes.
        
        :param key: the name of the variable
        """
        return self._find(key)[1] is not None
    has_key = __contains__

    def __delitem__(self, key):
        """Remove a variable from all scopes.
        
        :param key: the name of the variable
        """
        for frame in self.frames:
            if key in frame:
                del frame[key]

    def __getitem__(self, key):
        """Get a variables's value, starting at the current scope and going
        upward.
        
        :param key: the name of the variable
        :return: the variable value
        :raises KeyError: if the requested variable wasn't found in any scope
        """
        value, frame = self._find(key)
        if frame is None:
            raise KeyError(key)
        return value

    def __len__(self):
        """Return the number of distinctly named variables in the context.
        
        :return: the number of variables in the context
        """
        return len(self.items())

    def __setitem__(self, key, value):
        """Set a variable in the current scope.
        
        :param key: the name of the variable
        :param value: the variable value
        """
        self.frames[0][key] = value

    def _find(self, key, default=None):
        """Retrieve a given variable's value and the frame it was found in.

        Intended primarily for internal use by directives.
        
        :param key: the name of the variable
        :param default: the default value to return when the variable is not
                        found
        """
        for frame in self.frames:
            if key in frame:
                return frame[key], frame
        return default, None

    def get(self, key, default=None):
        """Get a variable's value, starting at the current scope and going
        upward.
        
        :param key: the name of the variable
        :param default: the default value to return when the variable is not
                        found
        """
        for frame in self.frames:
            if key in frame:
                return frame[key]
        return default

    def keys(self):
        """Return the name of all variables in the context.
        
        :return: a list of variable names
        """
        keys = []
        for frame in self.frames:
            keys += [key for key in frame if key not in keys]
        return keys

    def items(self):
        """Return a list of ``(name, value)`` tuples for all variables in the
        context.
        
        :return: a list of variables
        """
        return [(key, self.get(key)) for key in self.keys()]

    def update(self, mapping):
        """Update the context from the mapping provided."""
        self.frames[0].update(mapping)

    def push(self, data):
        """Push a new scope on the stack.
        
        :param data: the data dictionary to push on the context stack.
        """

    def pop(self):
        """Pop the top-most scope from the stack."""

    def copy(self):
        """Create a copy of this Context object."""
        # required to make f_locals a dict-like object
        # See http://genshi.edgewall.org/ticket/249 for
        # example use case in Twisted tracebacks
        ctxt = Context()
        ctxt.frames.pop()  # pop empty dummy context
        ctxt.frames.extend(self.frames)
        ctxt._match_templates.extend(self._match_templates)
        ctxt._choice_stack.extend(self._choice_stack)
        return ctxt


def _apply_directives(stream, directives, ctxt, vars):
    """Apply the given directives to the stream.
    
    :param stream: the stream the directives should be applied to
    :param directives: the list of directives to apply
    :param ctxt: the `Context`
    :param vars: additional variables that should be available when Python
                 code is executed
    :return: the stream with the given directives applied
    """
    if directives:
        stream = directives[0](iter(stream), directives[1:], ctxt, **vars)
    return stream


def _eval_expr(expr, ctxt, vars=None):
    """Evaluate the given `Expression` object.
    
    :param expr: the expression to evaluate
    :param ctxt: the `Context`
    :param vars: additional variables that should be available to the
                 expression
    :return: the result of the evaluation
    """
    if vars:
        ctxt.push(vars)
    retval = expr.evaluate(ctxt)
    if vars:
        ctxt.pop()
    return retval


def _exec_suite(suite, ctxt, vars=None):
    """Execute the given `Suite` object.
    
    :param suite: the code suite to execute
    :param ctxt: the `Context`
    :param vars: additional variables that should be available to the
                 code
    """
    if vars:
        ctxt.push(vars)
        ctxt.push({})
    suite.execute(ctxt)
    if vars:
        top = ctxt.pop()
        ctxt.pop()
        ctxt.frames[0].update(top)


class DirectiveFactoryMeta(type):
    """Meta class for directive factories."""

    def __new__(cls, name, bases, d):
        if 'directives' in d:
            d['_dir_by_name'] = dict(d['directives'])
            d['_dir_order'] = [directive[1] for directive in d['directives']]

        return type.__new__(cls, name, bases, d)


class DirectiveFactory(object):
    """Base for classes that provide a set of template directives.
    
    :since: version 0.6
    """
    __metaclass__ = DirectiveFactoryMeta

    directives = []
    """A list of ``(name, cls)`` tuples that define the set of directives
    provided by this factory.
    """

    def get_directive(self, name):
        """Return the directive class for the given name.
        
        :param name: the directive name as used in the template
        :return: the directive class
        :see: `Directive`
        """
        return self._dir_by_name.get(name)

    def get_directive_index(self, dir_cls):
        """Return a key for the given directive class that should be used to
        sort it among other directives on the same `SUB` event.
        
        The default implementation simply returns the index of the directive in
        the `directives` list.
        
        :param dir_cls: the directive class
        :return: the sort key
        """
        if dir_cls in self._dir_order:
            return self._dir_order.index(dir_cls)
        return len(self._dir_order)


class Template(DirectiveFactory):
    """Abstract template base class.
    
    This class implements most of the template processing model, but does not
    specify the syntax of templates.
    """

    EXEC = StreamEventKind('EXEC')
    """Stream event kind representing a Python code suite to execute."""

    EXPR = StreamEventKind('EXPR')
    """Stream event kind representing a Python expression."""

    INCLUDE = StreamEventKind('INCLUDE')
    """Stream event kind representing the inclusion of another template."""

    SUB = StreamEventKind('SUB')
    """Stream event kind representing a nested stream to which one or more
    directives should be applied.
    """

    serializer = None
    _number_conv = unicode # function used to convert numbers to event data

    def __init__(self, source, filepath=None, filename=None, loader=None,
                 encoding=None, lookup='strict', allow_exec=True):
        """Initialize a template from either a string, a file-like object, or
        an already parsed markup stream.
        
        :param source: a string, file-like object, or markup stream to read the
                       template from
        :param filepath: the absolute path to the template file
        :param filename: the path to the template file relative to the search
                         path
        :param loader: the `TemplateLoader` to use for loading included
                       templates
        :param encoding: the encoding of the `source`
        :param lookup: the variable lookup mechanism; either "strict" (the
                       default), "lenient", or a custom lookup class
        :param allow_exec: whether Python code blocks in templates should be
                           allowed
        
        :note: Changed in 0.5: Added the `allow_exec` argument
        """
        self.filepath = filepath or filename
        self.filename = filename
        self.loader = loader
        self.lookup = lookup
        self.allow_exec = allow_exec
        self._init_filters()
        self._init_loader()
        self._prepared = False

        if not isinstance(source, Stream) and not hasattr(ource, S'read'):
            if isinstance(source, unicode):
                source = StringIO(source)
            else:
                source = BytesIO(source)
        try:
            self._stream = self._parse(source, encoding)
        except ParseError, e:
            raise TemplateSyntaxError(e.msg, self.filepath, e.lineno, e.offset)

    def __getstate__(self):
        state = self.__dict__.copy()
        state['filtersrder']]
        return state

    def __setstate__(self, state):
        self.__dict__ = state
        self._init_filters()

    def __repr__(self):
        return '<%s "%s">' % (type(self).__name__, self.filename)

    def _init_filters(self):
        self.filters = [self._self)._   er']]
     ']]
     ']]
     ']]
   ,(dot'         self.fi.get_extimport T
            filenameshi.template.loader import TemplateLoader
from ge     if isinstalename)

               source stalename)

 file!=alename)

               source ename = veset #s. fil.norporth(lename)

 fil)[:de.ge                     allo#s. fil.norporth(lename)

    d               ], (), (              ],                source ename = veset #s. fil.vesnf, node)me)

    de         ],                source e = veset '    name = 

    d                 # If the name refers to a    e = Conf_lateEnginePtel,p evy ']]
   ,_parse  self.fi.get_extimh
     False

    self._stream = self._parse(soes))

    lse

   ( self._parse)self.default_doctyplse

       aise Undefinedr_order.indeeval_exp']]
   ,(encodinilepath=None,    excepop the top-mosncodfile relative     The default implemtemplat selgemtempesat which the er(oulunten'

siables
   setdefaultpply
    :pusedwill   "return: te
     (forma selgeare alarseErram allow_ep]
   upTelookkey)eare alaritream.""(   tem registe Falsd Pyt                                 ned', definen(selr(oulunten'

siables
   o :ppply
 
siab21   :pu for p in search_path if p],
                             xt stack.
 the tookup ding: the encoding of the `sourc whethntack.ML, 'XML': X`
        :param lookup: the variable lookup mechanism; either ef get_direct, e.lsformer(ASTTraplate',p the top-lse

      ,XML': X"
        # req  :rlepathttach`       lookML,rybases, d):
 self._filat selgemtempesat which the erplied to
    :paramML, 'XML': X line in the template at key in frame: ge     if isinstalename)

               sfoE     = [key for kekrseErractTepoder.ino
    frame[key]
      iadd(nd re(self, key):
      s that define the sinedr_order.iubctxt, **vaact[1]      _process(elt)
 _ prov,   upwary registesTepoder.inoors)tract[0]) node)me)

    de      s that d,.iubctxt, **vc:
  ttach     ,XMubctxt, ,   upwao)


class TemplateRuntimeError(Templaaaaaaaaaaaaaaaaaay registesTepod         source ename ream), direc:o)


class TemplateRuntim__metaclass       __metacla)the sinedr_order.iubctxt, **v_doctyplse

   ubctxt, )
   source ename ream), directr(node, 'args'):
     yt, atkrseEr(tives to thefault_ubctxt, ))Tepod veset #s. fil.vesnf, node)me)

    de     f __iL, 'Xr.in yt, atk:o)


class TemplateRuntimyt, atiL, '    name = 

    d                     iadd(ndnclusio:o)


class TemplateRuhref prov, f
        iilena       source ename rea StringIO(shref pr() in ('1' ives to o f
        io      self):
        return repr(list(self.frames))

  h, e.lineno, e.offset)

    def __getstat = unicode."""

    s%the given `Suite` object.
    
    :param suite: the code suite to execute
    :param ctxt: the `Context`
    :param vars: additional vaeif isinstalenameao
itional vaeif isins    i    nd  :param vars: additional vat: t-e `Conlename
dienerae `sourc vaeif isiparam cw         source ename = veset #s. fil.norRinlterdxt stathe given w         source ename = __dict__.copy()
  source ename = _. fs = MarkupTeg:
     Suite`aram loo_to= Teena_order.iubctxt, **v_doctyplse

   ubctxt, )
   source et)=the urc ']]
  elf):
 )order.iubctxt, **v_doctyplse
ource ename r_. f.StringIO(shref pr() in ('1' ives'1' ives to o f
        io      , vars=None):
def _t)
 _ prov,   upIO(shref pr() in ('1' ives'1'  the   def _'genshi.default_format', efault_format', 'htmlorder.iubctxt, **v_doctyplse
ource ename riL, 'Xr.in yt,e   def )among other directives on the same `SUB` event.
        
        The dupTeg:
     Suit            #-]1' ives a"ient",   def )amo if         iilena       source ename rea Strin  u       The dubcpr() in ('1' ives'1' ives to o f
   e vomr.in yt,e   def )among othTemplat%the given pply
    :pusedwill StringIOdorder_fdubcpr() 
li                 iadd(ndnc to d as part of th        callback=loader_callbac
esat = unicode."""

    s%the given `Suite` object.
    
    :pil)[:de.ge sedw    lookML,rybases, d):
 self._filat selgemtuite` (fxe` object.
    am.""(   tem m_tionaloe.'lf._filat selgemtuite` (fxe` ob      __iopply
              rder.iubctake it re_e.er_fdur           source ename rea Strance(node.slice, _ast.Index):
     kML,rwhe givenlse

      ,XML': X"
        :pil),ern reprte` obj  ca( sedw       ubctxt, )
   source ename re
 o f
   e vomr.in yt,e   defof the variable
  am bas variable
  rder.Falsd ind('EXEC')
    """Strinedrname re
 o f
   e vi         upTelookkey)eiste Falsdelookkey)eiste Falsdelooe er(oulunten'rste Falsde]rance(node.sliite   defmt whq1.filename = d['_dir_by_n.er_fdur   me)

   t',ename=None, loa d):
 self._filat sel_meloe.'lf._filat sey)eid.vomr.ih_path if
  ses,[]inedr_order.iubcth if if         iilena       tives to apply
xtra_vars_m vars: additional vaeif isinstale,ename=."""

 _filat sel_meloe.'le `sourc va classo apply)ions(format, fragment)
    tives to apply
xtra_vars_xpr.evaluate(ctxt).ge sStringIO(shref f
     e r_ing)

    snf, n:bute(self, node)(ctxt)   e r_
        ctxt.pretval


def _exec           Segiste untimyt.ge sS     temp                 return epoder.i.pretval


def :bute(self     :param fi.ge se     :paramsinstalenamedefault)n 0.5: Ade, retun diref pr()n 0.5: Ad return dirpopxpr.evaluate(ctxt)        ctxt_xpr.evaluwh   a1r(**kwargs)

    class       __metacla)the sil vaeif isinstalenameao
itio     
    :s'):
 c to d as part of th  # d())
    eErryla)platme)

  L': X line itacla) AttL':bast
elf):
 )order.iubctxt, *edw oameooku

  som})
    suite.exec(node.sliite   deaempl   "nal vat: t-e `Conlename
dien: thl   "nal ename ream), direc)

    c.
        "ram k   "c to d as part of th      he c        ""t os
ist:xt, *edwateSyname rpo      emplate causes f.use_package_naming:
  ""nal key)e:
     yt, atkrseEr(e dubcpr() in ('1' ives'1' ives to      retfault_uretval


def _exec    to d as part of th      he key)e:0         
    key)e:
      :return: theeeeeeeeeeeeeeeeeeeeeeeee]           #-]1' ives a"ient",   :re:
  ""yt,e   def )among othTemplat%the gder_fdubcpr() 
li            e_naming:
  "   "'.joamtfaultf _exec    to d as part of : thl   "ref pr()k.
        "")eno, e.offset)

    def __getstat eaemp    "(: thl   "iven `Su
 
li                 eao
itiosouryt,e   def )among othTen'rste= vars=None):     _ectives[1:]: t-e `Conlename
dieneraen'rsteef __init__(self, name, forder.iubctxt,Fir, sthedef pop(ookup mecoallback=loaderlook Straramself, name, forder.iubctxt,btypwt('oceedefof th. f.Strr(ouaplate',ch """
 ch`    self, name, forder.iubctxt,   'Templa,chather, n to d as part of th      he e `sourc vaen'rst                           e.offset)

    def __g      en'rst   `Suite` object.
                e `sourc vaen'rst  (ameooft)
t :pa                  e.offset)

    def __g           :paramaen'rst)   `Suite` object.
                state

 en'rst  '_    rConfigurationErrorhanged in 0.5: Ad    cn repr(list(self.framesute(self, node)(ctxt) :paramaen'rst)(list(self.framesute(self, nob)(ckuite` object.
             se              e.offset)

    def __g      ct__ = aen'rst)   `Su
 
li                 eao
itio_doctyplse

   ubctxtbctxt,sd inves'1' ther ef getf vars:
      + 1: ef getfsourcetyplse

   ubctxtbctxt,ves'1sing, file-thoste the given `Expression` obje
rrorhanged in 0.5: Ad    cn repr(list(self.framesute(de)(ctxt) eam = directives[:s'):
       r() _ectives[1:]: t-e `Conlename
dienb)(cku
 
li                 eao
itiosoECctyplse

   ubctxtbctx(type):
         _ectives[1:]:uite` object.
    
    :param suite: the coat selgemtuite` (fxe` objecrs: additional vaeif isinstalenam     tndnc to d as part of th  b)(ckuite` object.
   de)(ctxt)())
           ],      turn epoder.i.pretval


def :bute(selfor loe re
 ode)(ctx   e r      :at = usrom either a sectire
 
"lenient", or a cu   s.aaaay registesTepod         source ename ream), direc:o)


class TemplateRuntim__metacves'1' ive)the sinedr_order.iubckey)e:0     nal vaeif isins    i    nparam vars: additionalkey)e:
     yt, atkrseEr(     state['filtereif isiparam cw  c to d as part of th  t At"nal ename ream), direc)

    csubgemtuisubte` (fsub_metaclas to      retparam vetva, '    name = 

    d                     iadd(ndnclusiiiiiiiiiiiii


def :bute(selfh
     False

    seubgemt        igurationErrorhanged in 0.5: Ad At"ref pr()subte` )f isins    i    nd  :para   "'.joamt[x    cx
     At"n  sxeef __init__])f isins    i    ns'1' ives to o f
        , vars=None):
def _t)
 _ prov,   upIO(shrekey)e:2]r() in ('1' ives'1'  the   def _'genshi.default_fefault_format', 'htmlorder.iubctxt, **v_doctypl ename riL, 'Xr.in   am.""(retval


def :bute(selfothTemplat%the g